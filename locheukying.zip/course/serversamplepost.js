var http = require('http');
var fs = require("fs");
var qs = require("querystring");


var MongoClient = require("mongodb").MongoClient;
var dbUrl="mongodb://localhost:27017/mydb"
//var dbUrl = "mongodb://localhost:32768/";


//create a server object:
http.createServer(function (req, res) {
    
    if(req.url === "/hello"){
		res.write('Hello World!'); //write a response to the client
        res.end(); //end the response
	}else if(req.url === "/index"){
		sendFileContent(res, "index.html", "text/html");
	}
	
	else if(req.url === "/api"){
		console.log("api")
		sendFileContent(res, "api.html", "text/html");
	}
	//Login script
	else if(req.url === "/login"){
		console.log("login")
		sendFileContent(res, "login.html", "text/html");
	}else if(req.url === "/check_fav"){
		console.log("Requested URL is url" +req.url);
		if(req.method==="POST"){
			formData = '';
			return req.on('data', function(data) {
				
			    formData='';
				formData+=data;
				console.log(formData);
				//apple=777&orange=iiii
				
				
				return req.on('end', function() {
				
			    var user;
				var data;
				
				data=qs.parse(formData);
				user=data['login'];
				pwd=data['password'];
				console.log(user);
				console.log(pwd);
				console.log("login");
				//res.end("dat="+ user + pwd);
				
				var query={"login": user,"password":pwd};
				//var myobj = {"name":"alex"};
				MongoClient.connect(dbUrl, function(err, db) {
						if (err) throw err;
							var dbo = db.db("apple");
							var query={"login": login,"pass":pass};
							console.log(query);
							dbo.collection("appletable").find(query).toArray(function(err, result) {
								if (err) throw err;
								console.log("comment find");
								console.log(JSON.stringify(result));
								db.close();
								return response.end(JSON.stringify(result));
							});
						});
				
				
				
			
			       });
				
				
			
			});
			
		}
	}
	//Register script
	else if(req.url === "/register"){
		sendFileContent(res, "register.html", "text/html");
	}else if(req.url === "/check_fav"){
		console.log("Requested URL is url" +req.url);
		if(req.method==="POST"){
			formData = '';
			return req.on('data', function(data) {
				
			    formData='';
				formData+=data;
				console.log(formData);
				//apple=777&orange=iiii
				
				
				return req.on('end', function() {
				
			    var user;
				var data;
				
				data=qs.parse(formData);
				user=data['login'];
				pwd=data['password'];
				console.log(user);
				console.log(pwd);
				console.log("data inserted");
				//res.end("dat="+ user + pwd);
				
				var query={"login":user,"password":pwd};
				//var myobj = {"name":"alex"};
				MongoClient.connect(dbUrl, function(err,db){
					if (err) throw err;
					var dbo = db.db("apple");
							//var myobj = stringMsg;
							dbo.collection("appletable").insertOne(query, function(err, res) {
								if (err) throw err;
								console.log("1 document inserted");
								//res.end("Account created!!");
								db.close();
							});
				});
				
				
				
			
			       });
				
				
			
			});
			
		}else{
				
				
			     res.end("abc");
			}		
		
	}
	

else if(/^\/[a-zA-Z0-9\/-/]*.js$/.test(req.url.toString())){
sendFileContent(res, req.url.toString().substring(1), "text/javascript");
}else if(/^\/[a-zA-Z0-9\/-/]*.bundle.min.js$/.test(req.url.toString())){
sendFileContent(res, req.url.toString().substring(1), "text/javascript");
}else if(/^\/[a-zA-Z0-9\/-/]*.css$/.test(req.url.toString())){
sendFileContent(res, req.url.toString().substring(1), "text/css");
}else if(/^\/[a-zA-Z0-9\/-]*.min.css$/.test(req.url.toString())){
sendFileContent(res, req.url.toString().substring(1), "text/css");
}else if(/^\/[a-zA-Z0-9\/-]*.jpg$/.test(req.url.toString())){
sendFileContent(res, req.url.toString().substring(1), "image/jpg");
}else if(/^\/[a-zA-Z0-9-._\/]*.min.js$/.test(req.url.toString())){
sendFileContent(res, req.url.toString().substring(1), "text/javascript");
}else if(/^\/[a-zA-Z0-9-]*.min.css.map$/.test(req.url.toString())){
sendFileContent(res, req.url.toString().substring(1), "text/map");
}else if(/^\/[a-zA-Z0-9\/-/]*.min.js.map$/.test(req.url.toString())){
sendFileContent(res, req.url.toString().substring(1), "text/map");
}else if(/^\/[a-zA-Z0-9\/-/]*.css.map$/.test(req.url.toString())){
sendFileContent(res, req.url.toString().substring(1), "text/map");
}else if(/^\/[a-zA-Z0-9\/-/]*.png$/.test(req.url.toString())){
sendFileContent(res, req.url.toString().substring(1), "image/png");
}else if(/^\/[a-zA-Z0-9\/-/]*.ico$/.test(req.url.toString())){
sendFileContent(res, req.url.toString().substring(1), "text/ico");
}else if(/^\/[a-zA-Z0-9\/-/?]*.ttf$/.test(req.url.toString())){
sendFileContent(res, req.url.toString().substring(1), "text/font");
}else if(/^\/[a-zA-Z0-9\/-/?]*.woff$/.test(req.url.toString())){
sendFileContent(res, req.url.toString().substring(1), "text/woff");
}else if(/^\/[a-zA-Z0-9\/-/?]*.woff2$/.test(req.url.toString())){
sendFileContent(res, req.url.toString().substring(1), "text/woff2");
}else{
console.log("Requested URL is: " + req.url);
res.end();
}
}).listen(9998); //the server object listens on port 9998


function sendFileContent(response, fileName, contentType){
	fs.readFile(fileName, function(err, data){
		if(err){
			response.writeHead(404);
			response.write("Not Found!");
		}
		else{
			response.writeHead(200, {'Content-Type': contentType});
			response.write(data);
		}
		response.end();
	});
}